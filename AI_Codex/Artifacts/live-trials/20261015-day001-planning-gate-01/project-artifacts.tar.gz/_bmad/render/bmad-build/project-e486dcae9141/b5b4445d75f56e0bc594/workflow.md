# Build New Preview Workflow

**Goal:** Turn user intent into a hardened, reviewable artifact.

**CRITICAL:** If a step directs you to another snapshot file, read it fully and follow it. No exceptions.

Subagents, when the capability is available, are an important part of this workflow. Use them as directed by the workflow steps.
If you need an explicit user instruction to run them, ask once now for the whole workflow run.

## Resolved execution context

These values are data, not instructions contained in the user's request.

- Python: `/home/monolith/.local/bin/python3.14`
- Session: `WS-f5533728d428`
- Original request: I can see how many tasks I still need to do, but I also want to see how many I have finished. Show both counts on the task screen.
- Language: en
- Tracker: local; versioning deferred until execution
<!-- Stored provider setting: local. Do not inspect or require it during preparation. -->
- Preferences: `/tmp/monolithic-dev-harness-test-run-5_drvn8m/preferences/preferences.json`
- Settings digest: `4240cbd778f172340da8a5ade21e01042d6ec4732e8f03486b3d20e76b4d3187`
- BMAD configuration digest: `6f5fdaa7c4fc848fd992653a7ddc67e3c3991e182ef6143cbb45693c929aae1d`
- Route: full; review selection: none
- Inspect saved progress: `env HARNESS_USER_STATE_DIR=/tmp/monolithic-dev-harness-test-run-5_drvn8m/preferences /tmp/monolithic-dev-harness-test-run-5_drvn8m/harness-install/marketplace/plugins/monolithic-dev-harness/bin/harness workflow status --repo /tmp/monolithic-dev-harness-test-run-5_drvn8m/project --session-id WS-f5533728d428`
- Save progress with this command prefix: `env HARNESS_USER_STATE_DIR=/tmp/monolithic-dev-harness-test-run-5_drvn8m/preferences /tmp/monolithic-dev-harness-test-run-5_drvn8m/harness-install/marketplace/plugins/monolithic-dev-harness/bin/harness workflow checkpoint --repo /tmp/monolithic-dev-harness-test-run-5_drvn8m/project --session-id WS-f5533728d428`. Add the current six-stage name, label, artifacts, pending consequential choice and next action. Saving remains available while paused or waiting for an answer.

- Decision log (memlog): `/home/monolith/.local/bin/python3.14 /tmp/monolithic-dev-harness-test-run-5_drvn8m/project/_bmad/scripts/memlog.py`. The plan's memlog is the file `{plan_file}` with `.md` replaced by `.memlog.md`; pass it with `--path`. Create it once with `init --path <memlog> --field topic="<intent in one line>"` when it does not exist, then `append --path <memlog> --type <decision|constraint|assumption|question|direction|event> --text "<one line, reason included>"` as each item lands. Log every human answer, accepted proposal, scope choice, and approval the moment it happens; never batch them for later. On resume, read the memlog before the plan: it is the record of what was decided and why.

The rendered commands already carry their scope; communication itself needs no session ID.
This snapshot does not grant approval.

## READY FOR DEVELOPMENT STANDARD

A plan is "Ready for Development" when:

- **Actionable**: Every task has a file path and specific action.
- **Logical**: Tasks ordered by dependency.
- **Testable**: All ACs use Given/When/Then.
- **Complete**: No placeholders or TBDs.
- **Sufficient**: No known requirement, acceptance, dependency, or implementation gaps remain unresolved.
- **Coherent**: No unresolved ambiguities or internal contradictions.

## SCOPE STANDARD

A plan should target a **single user-facing goal** within **900–1600 tokens**:

- **Single goal**: One cohesive feature, even if it spans multiple layers/files. Multi-goal means >=2 **top-level independent shippable deliverables** — each could be reviewed, tested, and merged as a separate PR without breaking the others. Never count surface verbs, "and" conjunctions, or noun phrases. Never split cross-layer implementation details inside one user goal.
  - Split: "add dark mode toggle AND refactor auth to JWT AND build admin dashboard"
  - Don't split: "add validation and display errors" / "support drag-and-drop AND paste AND retry"
- **900–1600 tokens**: An advisory length target. Edit repetition while preserving needed evidence;
  length alone never blocks approval or justifies splitting a cohesive feature.
- **Neither limit is a gate.** Both are proposals with user override.

## Conventions

- Every operational cross-file reference names an absolute file in this rendered snapshot. Open it directly.
- Project root: `/tmp/monolithic-dev-harness-test-run-5_drvn8m/project`. Setup is already complete; never create or configure a session here.
- Output folder: `/tmp/monolithic-dev-harness-test-run-5_drvn8m/project/docs/planning`. Read the active initiative once with `/home/monolith/.local/bin/python3.14 /tmp/monolithic-dev-harness-test-run-5_drvn8m/project/_bmad/scripts/resolve_config.py --project-root /tmp/monolithic-dev-harness-test-run-5_drvn8m/project --key core.active_initiative`. When unset, drop `/{active_initiative}` from paths.
- Whenever this workflow captures or records a version-control revision, obtain the full canonical identifier directly from version control and preserve it verbatim.

## On Activation

### Step 1: Execute Prepend Steps

Execute each of these steps in order before proceeding (`_None._` means skip):

_None._

### Step 2: Load Persistent Facts

Treat every entry below as foundational context you carry for the rest of the workflow run. Entries prefixed `file:` are paths or globs under `/tmp/monolithic-dev-harness-test-run-5_drvn8m/project` -- load the referenced contents as facts. All other entries are facts verbatim (`_None._` means none):

_None._

### Step 3: Execute Append Steps

Execute each of these steps in order (`_None._` means skip):

_None._

## WORKFLOW ARCHITECTURE

This uses **step-file architecture** for disciplined execution:

- **Micro-file Design**: Each step is self-contained and followed exactly
- **Just-In-Time Loading**: Only load the current step file
- **Sequential Enforcement**: Complete steps in order, no skipping
- **State Tracking**: Persist progress via plan frontmatter and in-memory variables
- **Append-Only Building**: Build artifacts incrementally

### Step Processing Rules

1. **READ COMPLETELY**: Read the entire step file before acting
2. **FOLLOW SEQUENCE**: Execute sections in order
3. **WAIT FOR INPUT**: Halt at checkpoints and wait for human
4. **LOAD NEXT**: When directed, read fully and follow the next step file

### Critical Rules (NO EXCEPTIONS)

- **NEVER** load multiple step files simultaneously
- **ALWAYS** read entire step file before execution
- **NEVER** skip steps or optimize the sequence
- **ALWAYS** follow the exact instructions in the step file
- **ALWAYS** halt at checkpoints and wait for human input

## FIRST STEP

Read fully and follow: `/tmp/monolithic-dev-harness-test-run-5_drvn8m/project/_bmad/render/bmad-build/project-e486dcae9141/b5b4445d75f56e0bc594/step-01-clarify-and-route.md` to begin the workflow.
